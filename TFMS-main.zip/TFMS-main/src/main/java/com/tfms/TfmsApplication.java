package com.tfms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TfmsApplication {

    public static void main(String[] args) {
        SpringApplication.run(TfmsApplication.class, args);
    }
}